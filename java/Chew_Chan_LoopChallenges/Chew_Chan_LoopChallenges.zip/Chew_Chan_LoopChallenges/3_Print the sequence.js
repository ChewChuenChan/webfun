// Print the sequesnces

var i=4;    
while (i>-4){
    console.log(i);
    i=i-(1.5);
}